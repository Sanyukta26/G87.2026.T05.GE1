# G8X.2026.EG1.T00
Guided exercise 1 codebase.